import Fila from "../fila/fila";
import styles from "./Sala.module.css"

export default function Sala(props) {
    const { toggleSeat } = props;

    return (
        <div className={styles.container_filas}>
            <Fila toggleSeat={toggleSeat} />
            <Fila toggleSeat={toggleSeat} />
            <Fila toggleSeat={toggleSeat} />
            <Fila toggleSeat={toggleSeat} />
            <Fila toggleSeat={toggleSeat} />
            <Fila toggleSeat={toggleSeat} />
            <Fila toggleSeat={toggleSeat} />
            <Fila toggleSeat={toggleSeat} />
        <div className={styles.Tela}>
            <p>Tela</p>
        </div>
        <div className={styles.BlocoTela}>
            <div className={styles.AcentoCinzaTela}>
                </div>
        </div><br></br><br></br>
            <div className={styles.legenda}>
                <div className={styles.status}>
                    <div className={styles.AcentoBrancoBOLINHA}></div>
                    <p>Livre</p>
                </div>
                <div className={styles.status}>
                    <div className={styles.AcentoCinzaBOLINHA}></div>
                    <p>Indisponivel</p>
                </div>
                <div className={styles.status}>
                    <div className={styles.AcentoVermelhoBOLINHA}></div>
                    <p>Selecionado</p>
                </div>
            </div>
        </div>
    );
}